typedef struct 
{
    int x,y;
} point;

point init_point(int x, int y);

typedef struct
{
    point p;
    point c;
} move;

typedef struct
{
    int x,y;    
} mob;
