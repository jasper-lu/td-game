typedef struct {
    point p; 
    node *n;
} node;

typedef struct {
    node * s;
} queue;
