XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
X                                                                                        X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
