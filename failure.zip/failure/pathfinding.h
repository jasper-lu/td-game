#define ROWS 10 
#define COLS 10

int depth_move(point curr,char map[ROWS][COLS]);

int depth_moveh(point next, int dir, char map[ROWS][COLS]);
